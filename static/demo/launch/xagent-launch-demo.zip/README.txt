xAgent launch-kit demonstration, 2026-10-01

These three files are original exports from product previews. The actual run used two child sessions and file-reference handoffs. It included review and a follow-up instruction to finish and return launch copy, and is not an unattended first-pass result.

This is a demonstration record for review, not a real launch campaign or a current capability catalog. The fact-check preserves the official documents read during the run; some descriptions, including Word editing, require checking against current source/version evidence.

Original product download-button behavior was not verified. This ZIP is a website copy. No screenshots were input to the demonstrated task.
